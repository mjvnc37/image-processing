```python
import cv2
image = cv2.imread('C:/Users/User/Downloads/king.jpg')
#converting BGR to RGB
image_rgb=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
cv2.imshow('image',image_rgb)
cv2.waitKey(0)
cv2.destroyAllWindows()


```


```python
import cv2
image = cv2.imread('C:/Users/User/Downloads/king.jpg')
# Convert the image from RGB to BGR
image_rgb=cv2.cvtColor(image,cv2.COLOR_RGB2BGR)

# Display the BGR image
cv2.imshow('image',image_rgb)
cv2.waitKey(0)
cv2.destroyAllWindows()

```


```python
import cv2
img = cv2.imread('C:/Users/User/Downloads/king.jpg')
ret, bw_img=cv2.threshold(img, 123, 255, cv2.THRESH_BINARY)


#converting to its binary form
bw=cv2.threshold(img, 123, 255, cv2.THRESH_BINARY)
cv2.imshow("Binary",bw_img)
cv2.waitKey(0)
cv2.destroyAllWindows()

```


```python
import matplotlib.pyplot as plt
import cv2

im = cv2.imread('C:/Users/User/Downloads/king.jpg')
# calculate mean value from RGB channels and flatten to 1D array
vals = im.mean(axis=2).flatten()
# plot histogram with 255 bins
b, bins, patches = plt.hist(vals, 255)
plt.xlim([0,255])
plt.show()
```


    
![png](output_3_0.png)
    



```python

```
